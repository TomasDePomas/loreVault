# Character Name 

* categories
	* characters
	* some group name
* tags
	* some tag
	* another tag
* alignment
	* Neutral
	* Good

## Description

 Paragraphs written about the character. Loads of very interesting information## Some other sectionFurther information __detailing__stuff